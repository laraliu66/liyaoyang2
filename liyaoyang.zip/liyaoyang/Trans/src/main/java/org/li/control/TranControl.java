package org.li.control;


import java.util.List;

import org.li.entity.RTrans;
import org.li.entity.Transactions;
import org.li.serverImpl.TranServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@ComponentScan
@RestController("/Tran")
public class TranControl {

	@Autowired
	private TranServer tranServer;
	
    @GetMapping("/Add/{trandeID}/{version}/{securityCode}/{quantity}/{op}/{bs}")
	public Boolean AddTrans(@PathVariable("trandeID") int  trandeID,
			@PathVariable("version") int version,
			@PathVariable("securityCode") String securityCode,
			@PathVariable("quantity") Long quantity,
			@PathVariable("op") int op,
			@PathVariable("bs") int bs)
	{
		return tranServer.AddTrans(trandeID, version, securityCode, quantity, op, bs);
	}
    
    @GetMapping("/getAll")
    public List<Transactions> GetAll()
    {
    	return tranServer.GetAll();
    }
    
    
    @GetMapping("/ResultTrans")
    public List<RTrans> ResultTrans()
    {
    	return  tranServer.ResultTrans();
    }
    
    
    @GetMapping("/hello")
    public String GetHello()
    {
    	return "Hello";
    }
}
