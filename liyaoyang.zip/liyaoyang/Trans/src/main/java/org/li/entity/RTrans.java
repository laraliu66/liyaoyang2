package org.li.entity;

public class RTrans {

	private  String securtycode;
	
	private String quantity;

	public String getSecurtycode() {
		return securtycode;
	}

	public void setSecurtycode(String securtycode) {
		this.securtycode = securtycode;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "RTrans [securtycode=" + securtycode + ", quantity=" + quantity + "]";
	}
	
	
}
