package org.li.serverImpl;

import java.util.List;

import org.li.entity.RTrans;
import org.li.entity.Transactions;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

public interface TranImpl {

	public Boolean AddTrans(@PathVariable("trandeID") int  trandeID,
			@PathVariable("version") int version,
			@PathVariable("securityCode") String securityCode,
			@PathVariable("quantity") Long quantity,
			@PathVariable("op") int op,
			@PathVariable("bs") int bs);
    
    public List<Transactions> GetAll();
    
    
    public List<RTrans> ResultTrans();
    
}
