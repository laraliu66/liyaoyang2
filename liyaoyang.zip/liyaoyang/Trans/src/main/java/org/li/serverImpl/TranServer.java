package org.li.serverImpl;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.li.entity.RTrans;
import org.li.entity.Transactions;
import org.springframework.stereotype.Service;

@Service
public class TranServer implements TranImpl {
	
	private List<Transactions> listtrans=null;

	@Override
	public Boolean AddTrans(int trandeID, int version, String securityCode, Long quantity, int op, int bs) {
		// TODO Auto-generated method stub
		
		Transactions tran=new Transactions();
		tran.setTrandeID(trandeID);
		tran.setBuyORSell(bs);
		tran.setOperation(op);
		tran.setQuantity(quantity);
		tran.setSecurityCode(securityCode);
	    tran.setVersion(version);
	    tran.setTransactionID(listtrans==null?1:listtrans.size()+1);
	    listtrans.add(tran);
	    return true;
	}

	@Override
	public List<Transactions> GetAll() {
		// TODO Auto-generated method stub
		return listtrans;
	}

	@SuppressWarnings("unused")
	@Override
	public List<RTrans> ResultTrans() {
		// TODO Auto-generated method stub
		List<RTrans> listRTrans=null;
		List<RTrans> ResultItem=null;
		if(listtrans==null)
			return null;
		else 
		{
			for (Transactions ts : listtrans) {
				if(listRTrans==null)
				{
					RTrans rs=new RTrans();
					rs.setSecurtycode(ts.getSecurityCode());
					listRTrans.add(rs);
				}
				else
				{
					boolean exists =false;
					for(RTrans rt :listRTrans)
					{
						if (rt.getSecurtycode()==ts.getSecurityCode())
						{
							exists=true;
							break;
						}
					}
					if(!exists)
					{
						RTrans rs=new RTrans();
						rs.setSecurtycode(ts.getSecurityCode());
						listRTrans.add(rs);
					}
				}
			}
		}
		
		
		if(listtrans==null)
			return null;
		else
		{
			//过滤Cancel数据
			List<Transactions> fCancleList = listtrans.stream().filter(a->a.getOperation()==3).collect(Collectors.toList());
			
			//过滤Update 数据 
			List<Transactions> fuList = listtrans.stream().filter(a->a.getOperation()==2).collect(Collectors.toList());
			
			List<Transactions> ResultListTs=null;
			
			List<Transactions> ResultListTsend=null;
			
			for(Transactions tss:listtrans)
			{
				boolean exists=false;
				for( Transactions fcl:fCancleList)
				{
					if(tss.getTrandeID()==fcl.getTrandeID())
					{
						exists=true;
					}
				}
				if(!exists)
				{
					ResultListTs.add(tss);
				}
			}
			
			ArrayList<String> as=null;
			if(ResultListTs==null)
			{
				return null;
			}
			else
			{
				for(Transactions tsm :ResultListTs)
				{
					for(Transactions tk:fuList)
					{
						if(tsm.getTrandeID()==tk.getTrandeID()&&tsm.getTransactionID()!=tk.getTransactionID())
						{
							as.add(String.valueOf(tsm.getTransactionID()));
						}
					}
				}
				
			}
			
			
			for(Transactions tsm :ResultListTs)
			{
				for(String ss:as)
				{
					if(String.valueOf(tsm.getTransactionID())!=ss)
					{
						ResultListTsend.add(tsm);
					}
				
				}
			}
			
			
			for(RTrans rt :listRTrans)
			{
				int kresult=0;
				for(Transactions tkm:ResultListTsend)
				{
					if(rt.getSecurtycode()==tkm.getSecurityCode()&&tkm.getBuyORSell()==1)
					{
						kresult+=tkm.getQuantity();
					}
					else
					{
						kresult-=tkm.getQuantity();
					}
				}
				RTrans rts=new RTrans();
				rts.setSecurtycode(rt.getSecurtycode());
				rts.setQuantity(String.valueOf(kresult));
				ResultItem.add(rts);
				
			}
			return ResultItem;
		
		}
	}

}
